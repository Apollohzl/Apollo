import time as t
import random as ra
import json
from datetime import datetime as da
import k
"""
{
new_user("user","abcdef","19999999999")
new_user("apollo","abcdef","19999999999")
delete_user("usr")
modify_name("000000","new_name")
modify_password("000000","new_name")
modify_phone("000000","new_phone")
save_money("000000",5)
withdraw_money("000000",5)
withdraw_money("000000","999999",50)
}
"""





#json_str = '{"name": "Alice", "age": 30, "city": "New York"}'
#data = json.loads(json_str)#json=py

#data = {'name': 'Bob', 'age': 25, 'city': 'San Francisco'}
#json_str = json.dumps(data)#py=json

#file_path = "path/to/your/file.json"
#with open(file_path, 'r') as file:
    #data = file.read() #读取
#data['key'] = 'new value'
#with open('data.json', 'w') as file:
    #json.dump(data, file, indent=4) #写入
#with open(file_path, 'a') as file:
    #file.write("") #追加


#进度条函数
def progress_bar(length, percent):
    progress = int(length * percent)
    bar = "[" + "\033[92m->" * progress + "\033[91m*" * (length - progress)*2 + "\033[0m]"
    print("\r" + bar, "{:.0%}".format(percent), end="")

#调用
def fun(a=100):
    total = a
    for i in range(total + 1):
        percent = i / total
        progress_bar(20, percent)
        t.sleep(round(ra.uniform(0.1, 0.1), 2))
    print()

#用来创建各种操作
#历史记录快捷程序
def history_new(dat,math=9,money=0,name_1="",name_2=""):
    fun()
    if math == 1:
        dat[str(da.now())] = "register"
    elif math == 2:
        dat[str(da.now())] = "modify name"
    elif math == 3:
        dat[str(da.now())] = "modify password"
    elif math == 4:
        dat[str(da.now())] = "modify phone"
    elif math == 5:
        dat[str(da.now())] = "save money " + str(money) + "$"
    elif math == 6:
        dat[str(da.now())] = "withdraw money " + str(money) + "$"
    elif math == 7:
        dat[str(da.now())] = name_1 + " Transfer money " + str(money) + "$ to " + name_2
    elif math == 8:
        dat[str(da.now())] = name_2 + " received money " + str(money) + "$ from " + name_1
    elif math == 9:
        dat[str(da.now())] = "query money"
    elif math == 10:
        dat[str(da.now())] = "query history"




        
#最复杂的 创建用户->(传回数据必须为字符串'str')
def new_user(name,password,phone=""):
    #open json
    file_path = "bank\\msg\\xinxi.json"
    with open(file_path, 'r',encoding='utf-8') as file:
        data = json.load(file)
    #new id
    id_1 = ra.randint(100000,999999)
    for idd in range(len(data)):
        if data[str(idd)]['id'] == id_1:
            id_1 = ra.randint(100000,999999)
            continue
    id_2 = str(id_1)
    #make json str
    msg = {
        "name":name,
        "money":0,
        "id":id_2,
        "pass":password,
        "phone":phone,
        "history":{
            
        }
    }
    #make all
    history_new(msg['history'],1)
    data[str(len(data))] = msg
    #write into
    with open(file_path, 'w',encoding='utf-8') as file:
        json.dump(data, file,  ensure_ascii=False, indent=4)


    print("创建成功! 以下为您的卡信息:")
    k.fk_xxa(50,["冥行卡信息","您的名字: "+name,"您的卡号: "+id_2,"您的手机号: "+phone,"创建日期:"+str(da.now()),"\033[92;41m请认真记住您的信息，特别是卡号!!"],1)
    return id_2
#delete user(id)
def delete_user(id):
    #open json
    file_path = "bank\\msg\\xinxi.json"
    with open(file_path, 'r',encoding='utf-8') as file:
        data = json.load(file)
    for i in range(len(data)):
        if data[str(i)]['id'] == id:
            print("删除中。。。")
            fun(50)
            del data[str(i)]
            # 遍历原字典的键值对
            n_data={}
            for key, value in data.items():
                if int(key) >= i:
                    new_key = str(int(key)-1)  # 将'old_key1'更改为'new_key1'
                    n_data[new_key] = value
                else:
                    print("nothing")
                    n_data[key] = value
            data = n_data
            print("删除成功!")
            break
    else:
        print("查无用户")
    with open(file_path, 'w',encoding='utf-8') as file:
        json.dump(data, file, indent=4)

#modify name(id,new_name)
def modify_name(id,new_name):
    #open json
    file_path = "bank\\msg\\xinxi.json"
    with open(file_path, 'r',encoding='utf-8') as file:
        data = json.load(file)
    for i in range(len(data)):
        if data[str(i)]['id'] == id:
            data[str(i)]['name'] = new_name
            history_new(data[str(i)]['history'],2)
            print("修改成功!")
            break
    else:
        print("查无用户")
    with open(file_path, 'w',encoding='utf-8') as file:
        json.dump(data, file,  ensure_ascii=False, indent=4)

#modify password(id,new_password)
def modify_password(id,new_password):
    #open json
    file_path = "bank\\msg\\xinxi.json"
    with open(file_path, 'r',encoding='utf-8') as file:
        data = json.load(file)
    for i in range(len(data)):
        if data[str(i)]['id'] == id:
            data[str(i)]['pass'] = new_password
            history_new(data[str(i)]['history'],3)
            print("修改成功!")
            break
    else:
        print("查无用户")
    with open(file_path, 'w',encoding='utf-8') as file:
        json.dump(data, file, indent=4)

#modify phone(id,new_password)
def modify_phone(id,new_phone):
    #open json
    file_path = "bank\\msg\\xinxi.json"
    with open(file_path, 'r',encoding='utf-8') as file:
        data = json.load(file)
    for i in range(len(data)):
        if data[str(i)]['id'] == id:
            data[str(i)]['phone'] = new_phone
            history_new(data[str(i)]['history'],4)
            print("修改成功!")
            break
    else:
        print("查无用户")
    with open(file_path, 'w',encoding='utf-8') as file:
        json.dump(data, file, indent=4)

def save_money(id,money):
    #open json
    file_path = "bank\\msg\\xinxi.json"
    with open(file_path, 'r',encoding='utf-8') as file:
        data = json.load(file)
    for i in range(len(data)):
        if data[str(i)]['id'] == id:
            last_money = data[str(i)]['money']
            new_money = last_money +money
            data[str(i)]['money'] = new_money
            history_new(data[str(i)]['history'],5,money)
            print("存钱成功!")
            break
    else:
        print("无该用户")
    with open(file_path, 'w',encoding='utf-8') as file:
        json.dump(data, file, indent=4)

def withdraw_money(id,money):
    #open json
    file_path = "bank\\msg\\xinxi.json"
    with open(file_path, 'r',encoding='utf-8') as file:
        data = json.load(file)
    for i in range(len(data)):
        if data[str(i)]['id'] == id:
            last_money = data[str(i)]['money']
            if last_money > money:
                new_money = last_money - money
                data[str(i)]['money'] = new_money
                history_new(data[str(i)]['history'],6,money)
                print("取钱成功!")
            else:
                print("金额不足")
            break
    else:
        print("无该用户")
    with open(file_path, 'w') as file:
        json.dump(data, file, indent=4)

def Transfer_money(id_1,id_2,money):
     #open json
    file_path = "bank\\msg\\xinxi.json"
    with open(file_path, 'r',encoding='utf-8') as file:
        data = json.load(file)
    for i in range(len(data)):
        if data[str(i)]['id'] == id_1:
            for e in range(len(data)):
                if data[str(e)]['id'] == id_2:
                        
                                #id_1:
                                last_money = data[str(i)]['money']
                                if last_money > money:
                                    new_money = last_money - money
                                    data[str(i)]['money'] = new_money
                                else:
                                    print("余额不足")
                                    break
                                #id_2:
                                last_money = data[str(e)]['money']
                                new_money = last_money + money
                                data[str(e)]['money'] = new_money
                                history_new(data[str(i)]['history'],7,money,id_1,id_2)
                                history_new(data[str(e)]['history'],8,money,id_1,id_2)
                                break
            else:
                print("查无收款方用户")
    else:
        print("查无转账方用户")
    with open(file_path, 'w') as file:
        json.dump(data, file, indent=4)




def query_money(id):
    #open json
    file_path = "bank\\msg\\xinxi.json"
    with open(file_path, 'r',encoding='utf-8') as file:
        data = json.load(file)
    for i in range(len(data)):
        if data[str(i)]['id'] == id:
            history_new(data[str(i)]['history'],9)
            print("当前余额: ",data[str(i)]['money'])
            break
    else:
        print("查无用户")
    with open(file_path, 'w',encoding='utf-8') as file:
        json.dump(data, file, indent=4)


def query_history(id):
    #open json
    file_path = "bank\\msg\\xinxi.json"
    with open(file_path, 'r',encoding='utf-8') as file:
        data = json.load(file)
    for i in range(len(data)):
        if data[str(i)]['id'] == id:
            history_new(data[str(i)]['history'],10)
            history = data[str(i)]['history']
            for xinxi_history in history:
                print(xinxi_history)
                t.sleep(0.2)
            break
    else:
        print("查无用户")
    with open(file_path, 'w',encoding='utf-8') as file:
        json.dump(data, file, indent=4)
