import tkinter as tk
from tkinter import messagebox

import k  # 假设你有一个名为 k.py 的模块


class BankApp:
    def __init__(self, root):
        self.root = root
        self.root.title("天地银行(sky floor bank)")
        self.root.geometry("400x300")

        self.main_frame = tk.Frame(self.root)
        self.main_frame.pack(pady=20)

        self.welcome_label = tk.Label(self.main_frame, text="欢迎来到天地银行(sky floor bank)~~~", font=("Arial", 14))
        self.welcome_label.pack()

        self.options = ["注册", "存取", "转账", "查询", "其它"]
        self.create_buttons()

    def create_buttons(self):
        for idx, option in enumerate(self.options):
            button = tk.Button(self.main_frame, text=option, command=lambda idx=idx: self.handle_option(idx + 1))
            button.pack(pady=5)

    def handle_option(self, option):
        if option == 1:
            k.new()  # 注册
        elif option == 2:
            self.open_transaction_window()
        elif option == 3:
            k.t_money()  # 转账
        elif option == 4:
            self.open_query_window()
        elif option == 5:
            self.open_logout_window()

    def open_transaction_window(self):
        self.root.withdraw()  # 隐藏主窗口
        transaction_window = tk.Toplevel(self.root)
        transaction_window.title("存取")
        transaction_window.geometry("200x150")

        tk.Button(transaction_window, text="存钱", command=lambda: self.perform_transaction('存钱', k.s_money, transaction_window)).pack(pady=5)
        tk.Button(transaction_window, text="取钱", command=lambda: self.perform_transaction('取钱', k.w_money, transaction_window)).pack(pady=5)
        tk.Button(transaction_window, text="取消", command=lambda: self.kong(transaction_window)).pack(pady=5)        

    def kong(self,window):
        window.destroy()
        self.root.deiconify()
    def open_query_window(self):
        self.root.withdraw()  # 隐藏主窗口
        query_window = tk.Toplevel(self.root)
        query_window.title("查询")
        query_window.geometry("200x150")

        tk.Button(query_window, text="查询余额", command=lambda: self.perform_query('查询余额', k.q_money, query_window)).pack(pady=5)
        tk.Button(query_window, text="查询历史", command=lambda: self.perform_query('查询历史', k.q_history, query_window)).pack(pady=5)
        tk.Button(query_window, text="取消", command=lambda: self.kong(query_window)).pack(pady=5)  

    def perform_transaction(self, action, func, window):
        func()  # 执行存取函数
        window.destroy()  # 关闭当前窗口
        self.root.deiconify()  # 显示主窗口

    def perform_query(self, action, func, window):
        func()  # 执行查询函数
        window.destroy()  # 关闭当前窗口
        self.root.deiconify()  # 显示主窗口

    def open_logout_window(self):
        logout_window = tk.Toplevel(self.root)
        logout_window.title("注销账号")
        logout_window.geometry("200x150")

        tk.Button(logout_window, text="注销账号", command=k.delete).pack(pady=5)
        tk.Button(logout_window, text="退出", command=self.exit_application).pack(pady=5)

    def exit_application(self):
        messagebox.showinfo("退出", "欢迎下次光临~亲")
        self.root.quit()


if __name__ == "__main__":
    root = tk.Tk()
    app = BankApp(root)
    root.mainloop()
