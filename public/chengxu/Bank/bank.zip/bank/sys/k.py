import syste as s
import msvcrt
import time as ti
def get_password(prompt):
    password = ""
    print(prompt, end='', flush=True)
    
    while True:
        key = msvcrt.getch()
        try:
            key = key.decode("utf-8")
        
            if key == '\r':  # 回车键
                print()
                break
            elif key == '\b':  # 退格键
                if password:
                    password = password[:-1]
                    print("\b \b", end='', flush=True)
            elif len(password) == 6:
                pass
            else:
                password += key
                print("*", end='', flush=True)
        except:
            continue
    return password
def f():
    print("\033[0m-----------------------------------")
def new():
    print("\033[92;42m")
    f()
    name = input("\033[92;42m请输入你的新名字：")
    print()
    password = get_password("请输入你的密码：")
    while True:
        try:
            phone = input("\n\033[0m请输入你的手机号：(可不填)")
            if type(phone)!=type(1):
                if 11>len(phone)>0 or len(phone)>11:
                    len(777)
                elif len(phone)==11:
                    True
                elif len(phone)==0:
                    True
            else:
                1/0
        except TypeError:
            print("\033[1A",end="")
            print("\033[K",end="")
            print("\033[1;31m输入有误，请重新输入\033[92;42m")
            print("\033[2A",end="")
            ti.sleep(1)
            print
            continue
        except ZeroDivisionError:
            print("\033[1A",end="")
            print("\033[K",end="")
            print("\033[1;31mtypeError\033[92;42m")
            print("\033[2A",end="")
            ti.sleep(1)
            print
            continue
        break
    f()
    print("\033[0m")
    s.new_user(name,password,phone) 
       
def delete():
    print("\033[92;41m")
    f()
    delete_user_id = input("\033[92;41m请输入注销账户id：")
    yn = input("宁确定要注销此账户吗yn？")
    if yn == "y":
        s.delete_user(delete_user_id)
        print()
        f()
    print("\033[0m")
def m_name():
    print("\033[92;44m")
    f()
    m_id = input("\033[92;44m请输入更改账号id:")
    m_name = input("请输入更改的名字:")
    s.modify_name(m_id,m_name)
    print()
    f()
    print("\033[0m")
def m_password():
    print("\033[92;44m")
    f()
    m_id = input("\033[92;44m请输入更改账号id:")
    m_password = get_password("请输入更改密码: ")
    s.modify_password(m_id,m_password)
    print()
    f()
    print("\033[0m")
def m_phone():
    print("\033[92;44m")
    f()
    m_id = input("\033[92;44m请输入更改账号id:")
    while True:
        try:
            m_phone = input("\n\033[0m请输入你的手机号：(可不填)")
            if type(m_phone)!=type(1):
                if 11>len(m_phone)>0 or len(m_phone)>11:
                    len(777)
                elif len(m_phone)==11:
                    True
                elif len(m_phone)==0:
                    True
            else:
                1/0
        except TypeError:
            print("\033[1A",end="")
            print("\033[K",end="")
            print("\033[1;31m输入有误，请重新输入\033[92;42m")
            print("\033[2A",end="")
            ti.sleep(1)
            print
            continue
        except ZeroDivisionError:
            print("\033[1A",end="")
            print("\033[K",end="")
            print("\033[1;31mtypeError\033[92;42m")
            print("\033[2A",end="")
            ti.sleep(1)
            print
            continue
        break
    s.modify_phone(m_id,m_phone)
    print()
    f()
def s_money():
    print("\033[92;45m")
    f()
    s_id = input("\033[92;45m请输入存钱id:")
    while True:
        try:
            s_money = int(input("请输入存钱金额: "))
        except:
            print()
            print("\033[1A",end="")
            print("\033[K",end="")
            print("\033[1;31m输入有误,请重新输入\033[92;45m")
            print("\033[2A",end="")
            ti.sleep(1)
            print
            continue
        break
    s.save_money(s_id,s_money)
    print()
    f()
    print("\033[0m")
def w_money():
    print("\033[92;45m")
    f()
    w_id = input("\033[92;45m请输入取钱id: ")
    while True:
        try:
            w_money = int(input("请输入取钱金额: "))
        except:
            print("\033[1A",end="")
            print("\033[K",end="")
            print("\033[1;31m输入有误,请重新输入\033[92;45m")
            print("\033[2A",end="")
            ti.sleep(1)
            print
            continue
        break
    s.withdraw_money(w_id,w_money)
    print()
    f()    
    print("\033[0m")
def t_money():
    print("\033[92;41m")
    f()
    z_id = input("\033[92;41m请输入转账方id: ")
    s_id = input("请输入收款方id: ")
    while True:
        try:
            z_money = int(input("请输入转账金额: "))
        except:
            print("\033[1A",end="")
            print("\033[K",end="")
            print("\033[1;31m输入有误,请重新输入\033[92;41m")
            print("\033[2A",end="")
            ti.sleep(1)
            print
            continue
        break
    s.Transfer_money(z_id,s_id,z_money)
    print()
    f()    
    print("\033[0m")
def q_money():
    print("\033[92;45m")
    f()
    q_id = input("\033[92;45m请输入查询id: ")
    s.query_money(q_id)
    print()
    f()    
    print("\033[0m")
def q_history():
    print("\033[92;45m")
    f()
    q_id = input("\033[92;45m请输入查询id: ")
    s.query_history(q_id)
    print()
    f()    
    print("\033[0m")